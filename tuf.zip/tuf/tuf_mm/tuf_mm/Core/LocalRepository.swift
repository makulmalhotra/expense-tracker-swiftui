import Foundation
import Observation

@Observable
final class LocalRepository {

    private(set) var isAuthenticated: Bool      = false
    private(set) var currentUser: User?
    private(set) var transactions: [Transaction] = []
    private(set) var currencies: [Currency]      = []
    private(set) var isDarkMode: Bool            = true

    private var registeredUsers: [String: User] = [:]

    private enum Key {
        static let currentUser     = "lr_currentUser"
        static let transactions    = "lr_transactions"
        static let registeredUsers = "lr_registeredUsers"
        static let currencies      = "lr_currencies"
        static let isDarkMode      = "lr_isDarkMode"
    }

    init() {
        loadFromStorage()
        if currencies.isEmpty { currencies = Currency.defaults }
    }

    func setDarkMode(_ enabled: Bool) {
        isDarkMode = enabled
        UserDefaults.standard.set(enabled, forKey: Key.isDarkMode)
    }

    // MARK: - Auth

    @discardableResult
    func signIn(email: String, password: String) -> String? {
        let key = email.trimmed.lowercased()
        guard let user = registeredUsers[key] else { return "No account found with this email." }
        guard user.password == password else { return "Incorrect password." }
        currentUser = user
        isAuthenticated = true
        persist(\.currentUser)
        return nil
    }

    @discardableResult
    func signUp(fullName: String, email: String, password: String) -> String? {
        let key = email.trimmed.lowercased()
        guard registeredUsers[key] == nil else { return "An account with this email already exists." }
        let user = User(
            id: UUID(),
            fullName: fullName.trimmed,
            email: email.trimmed,
            password: password,
            cardNumber: Self.makeCardNumber(),
            bankName: "PayU",
            cardExpiry: Self.makeCardExpiry()
        )
        registeredUsers[key] = user
        currentUser = user
        isAuthenticated = true
        persistAll()
        return nil
    }

    func signOut() {
        currentUser = nil
        isAuthenticated = false
        UserDefaults.standard.removeObject(forKey: Key.currentUser)
    }

    @discardableResult
    func updateProfile(fullName: String, email: String, newPassword: String?) -> String? {
        guard var user = currentUser else { return "Not authenticated." }
        let oldKey = user.email.trimmed.lowercased()
        let newKey = email.trimmed.lowercased()
        if newKey != oldKey, registeredUsers[newKey] != nil {
            return "This email is already registered to another account."
        }
        user.fullName = fullName.trimmed
        user.email    = email.trimmed
        if let pwd = newPassword, !pwd.isEmpty { user.password = pwd }
        registeredUsers.removeValue(forKey: oldKey)
        registeredUsers[newKey] = user
        currentUser = user
        persistAll()
        return nil
    }

    // MARK: - Currencies

    func toggleCurrencyEnabled(id: String) {
        guard let idx = currencies.firstIndex(where: { $0.id == id }) else { return }
        currencies[idx].isEnabled.toggle()
        persistCurrencies()
    }

    func toggleCurrencyFavorite(id: String) {
        guard let idx = currencies.firstIndex(where: { $0.id == id }) else { return }
        currencies[idx].isFavorite.toggle()
        persistCurrencies()
    }

    // MARK: - Transactions

    func addTransaction(_ tx: Transaction) {
        transactions.append(tx)
        persistTransactions()
    }

    func updateTransaction(_ updated: Transaction) {
        guard let idx = transactions.firstIndex(where: { $0.id == updated.id }) else { return }
        transactions[idx] = updated
        persistTransactions()
    }

    func deleteTransaction(id: UUID) {
        transactions.removeAll { $0.id == id }
        persistTransactions()
    }

    func toggleFavorite(id: UUID) {
        guard let idx = transactions.firstIndex(where: { $0.id == id }) else { return }
        transactions[idx].isFavorite.toggle()
        persistTransactions()
    }

    // MARK: - Persistence

    private func loadFromStorage() {
        let dec = JSONDecoder()
        if let d = UserDefaults.standard.data(forKey: Key.currentUser),
           let u = try? dec.decode(User.self, from: d) {
            currentUser = u
            isAuthenticated = true
        }
        if let d = UserDefaults.standard.data(forKey: Key.transactions),
           let t = try? dec.decode([Transaction].self, from: d) {
            transactions = t
        }
        if let d = UserDefaults.standard.data(forKey: Key.registeredUsers),
           let u = try? dec.decode([String: User].self, from: d) {
            registeredUsers = u
        }
        if let d = UserDefaults.standard.data(forKey: Key.currencies),
           let c = try? dec.decode([Currency].self, from: d) {
            currencies = c
        }
        if let v = UserDefaults.standard.object(forKey: Key.isDarkMode) as? Bool {
            isDarkMode = v
        }
    }

    private func persistAll() {
        persist(\.currentUser)
        persistTransactions()
        persistRegisteredUsers()
        persistCurrencies()
    }

    private func persist(_ keyPath: KeyPath<LocalRepository, User?>) {
        guard let enc = try? JSONEncoder().encode(currentUser) else { return }
        UserDefaults.standard.set(enc, forKey: Key.currentUser)
    }

    private func persistTransactions() {
        guard let enc = try? JSONEncoder().encode(transactions) else { return }
        UserDefaults.standard.set(enc, forKey: Key.transactions)
    }

    private func persistRegisteredUsers() {
        guard let enc = try? JSONEncoder().encode(registeredUsers) else { return }
        UserDefaults.standard.set(enc, forKey: Key.registeredUsers)
    }

    private func persistCurrencies() {
        guard let enc = try? JSONEncoder().encode(currencies) else { return }
        UserDefaults.standard.set(enc, forKey: Key.currencies)
    }

    private static func makeCardNumber() -> String {
        (0..<4).map { _ in String(format: "%04d", Int.random(in: 1000...9999)) }
               .joined(separator: " ")
    }

    private static func makeCardExpiry() -> String {
        let future = Calendar.current.date(byAdding: .year, value: 4, to: Date()) ?? Date()
        let c = Calendar.current.dateComponents([.month, .year], from: future)
        return String(format: "%02d/%02d", c.month ?? 1, (c.year ?? 2028) % 100)
    }
}

private extension String {
    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
}
