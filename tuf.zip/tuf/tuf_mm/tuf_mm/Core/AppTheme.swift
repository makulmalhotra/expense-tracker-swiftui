import SwiftUI
import UIKit

extension Color {
    init(hex: String) {
        let str = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var rgb: UInt64 = 0
        Scanner(string: str).scanHexInt64(&rgb)
        let r, g, b, a: Double
        switch str.count {
        case 3:
            r = Double((rgb >> 8) & 0xF) / 15
            g = Double((rgb >> 4) & 0xF) / 15
            b = Double( rgb       & 0xF) / 15
            a = 1
        case 6:
            r = Double((rgb >> 16) & 0xFF) / 255
            g = Double((rgb >>  8) & 0xFF) / 255
            b = Double( rgb        & 0xFF) / 255
            a = 1
        case 8:
            r = Double((rgb >> 24) & 0xFF) / 255
            g = Double((rgb >> 16) & 0xFF) / 255
            b = Double((rgb >>  8) & 0xFF) / 255
            a = Double( rgb        & 0xFF) / 255
        default:
            r = 0; g = 0; b = 0; a = 1
        }
        self.init(.sRGB, red: r, green: g, blue: b, opacity: a)
    }
}

extension UIColor {
    convenience init(hexString: String) {
        let str = hexString.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var rgb: UInt64 = 0
        Scanner(string: str).scanHexInt64(&rgb)
        let r = CGFloat((rgb >> 16) & 0xFF) / 255
        let g = CGFloat((rgb >>  8) & 0xFF) / 255
        let b = CGFloat( rgb        & 0xFF) / 255
        self.init(red: r, green: g, blue: b, alpha: 1)
    }
}

enum AppTheme {

    // Uses UIColor dynamic provider so colors respond to the system trait without
    // needing @Environment(\.colorScheme) in every view.
    private static func adaptive(light: String, dark: String) -> Color {
        Color(UIColor { trait in
            trait.userInterfaceStyle == .dark
                ? UIColor(hexString: dark)
                : UIColor(hexString: light)
        })
    }

    static let background    = adaptive(light: "#F2F2F7", dark: "#1C1C1E")
    static let cardBg        = adaptive(light: "#FFFFFF", dark: "#2C2C2E")
    static let surface       = adaptive(light: "#E5E5EA", dark: "#3A3A3C")
    static let inputBg       = adaptive(light: "#EBEBF0", dark: "#252527")
    static let separator     = adaptive(light: "#C6C6C8", dark: "#38383A")

    static let accent        = Color(hex: "#00D4AA")
    static let warning       = Color(hex: "#FF9F0A")
    static let danger        = Color(hex: "#FF453A")
    static let success       = Color(hex: "#30D158")

    static let textPrimary   = adaptive(light: "#1C1C1E", dark: "#FFFFFF")
    static let textSecondary = adaptive(light: "#636366", dark: "#8E8E93")

    // Physical card stays dark in both light and dark mode — intentional
    static let cardGradient = LinearGradient(
        colors: [Color(hex: "#0A3D2E"), Color(hex: "#155C42"), Color(hex: "#1E7A58")],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )

    static let cornerRadius: CGFloat      = 16
    static let cornerRadiusSmall: CGFloat = 12
}

struct InputFieldStyle: ViewModifier {
    var isFocused: Bool = false
    func body(content: Content) -> some View {
        content
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
            .background(AppTheme.inputBg)
            .cornerRadius(AppTheme.cornerRadiusSmall)
            .overlay(
                RoundedRectangle(cornerRadius: AppTheme.cornerRadiusSmall)
                    .stroke(isFocused ? AppTheme.accent : AppTheme.separator, lineWidth: 1)
            )
    }
}

extension View {
    func inputFieldStyle(focused: Bool = false) -> some View {
        modifier(InputFieldStyle(isFocused: focused))
    }
}

extension Double {
    func formatted(symbol: String = "$") -> String {
        let f = NumberFormatter()
        f.numberStyle = .decimal
        f.minimumFractionDigits = 0
        f.maximumFractionDigits = 2
        return "\(symbol)\(f.string(from: NSNumber(value: self)) ?? "0")"
    }
}
