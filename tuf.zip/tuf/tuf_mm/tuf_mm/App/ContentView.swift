import SwiftUI

struct ContentView: View {

    @Environment(LocalRepository.self) private var repository

    var body: some View {
        Group {
            if repository.isAuthenticated {
                MainTabView(repository: repository)
                    .transition(.asymmetric(
                        insertion: .move(edge: .trailing).combined(with: .opacity),
                        removal:   .move(edge: .leading).combined(with: .opacity)
                    ))
            } else {
                AuthScreen(repository: repository)
                    .transition(.asymmetric(
                        insertion: .move(edge: .leading).combined(with: .opacity),
                        removal:   .move(edge: .trailing).combined(with: .opacity)
                    ))
            }
        }
        .animation(.easeInOut(duration: 0.35), value: repository.isAuthenticated)
    }
}

// Holds the AuthViewModel so form state survives ContentView re-renders
private struct AuthScreen: View {
    @State private var viewModel: AuthViewModel

    init(repository: LocalRepository) {
        _viewModel = State(initialValue: AuthViewModel(repository: repository))
    }

    var body: some View {
        AuthView(viewModel: viewModel)
    }
}
