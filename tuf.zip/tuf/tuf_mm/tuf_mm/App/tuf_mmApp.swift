import SwiftUI

@main
struct tuf_mmApp: App {

    @State private var repository = LocalRepository()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(repository)
                .preferredColorScheme(repository.isDarkMode ? .dark : .light)
        }
    }
}
