import SwiftUI

struct TopBar: View {
    var body: some View {
        HStack {
            HStack(spacing: 8) {
                PayULogo(size: 32)
                Text("PayU")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(AppTheme.textPrimary)
            }
            Spacer()
            HStack(spacing: 18) {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 20))
                    .foregroundColor(AppTheme.textPrimary)
                ZStack(alignment: .topTrailing) {
                    Image(systemName: "bell.fill")
                        .font(.system(size: 20))
                        .foregroundColor(AppTheme.textPrimary)
                    Circle().fill(Color.red)
                        .frame(width: 8, height: 8)
                        .offset(x: 2, y: -2)
                }
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 16)
        .padding(.bottom, 8)
    }
}

struct PayULogo: View {
    var size: CGFloat = 32
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.25)
                .fill(Color.white)
                .frame(width: size, height: size)
            Text("P")
                .font(.system(size: size * 0.55, weight: .bold))
                .foregroundColor(.black)
        }
    }
}

struct SegmentControl: View {
    let options: [String]
    @Binding var selectedIndex: Int

    var body: some View {
        HStack(spacing: 0) {
            ForEach(options.indices, id: \.self) { idx in
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) { selectedIndex = idx }
                } label: {
                    Text(options[idx])
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundColor(selectedIndex == idx ? .black : AppTheme.textSecondary)
                        .frame(maxWidth: .infinity)
                        .frame(height: 40)
                        .background(selectedIndex == idx ? Color.white : Color.clear)
                        .cornerRadius(8)
                        .padding(3)
                }
            }
        }
        .background(AppTheme.surface)
        .cornerRadius(10)
    }
}

struct InputField: View {
    let label: String
    let placeholder: String
    @Binding var text: String
    var isEmail: Bool = false

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label)
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(AppTheme.textSecondary)
            TextField(placeholder, text: $text)
                .keyboardType(isEmail ? .emailAddress : .default)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .font(.system(size: 15))
                .foregroundColor(AppTheme.textPrimary)
                .inputFieldStyle()
        }
    }
}

struct SecureInputField: View {
    let label: String
    let placeholder: String
    @Binding var text: String
    @Binding var isVisible: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label)
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(AppTheme.textSecondary)
            HStack {
                Group {
                    if isVisible {
                        TextField(placeholder, text: $text)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                    } else {
                        SecureField(placeholder, text: $text)
                    }
                }
                .font(.system(size: 15))
                .foregroundColor(AppTheme.textPrimary)
                Button { isVisible.toggle() } label: {
                    Image(systemName: isVisible ? "eye.slash" : "eye")
                        .foregroundColor(AppTheme.textSecondary)
                        .frame(width: 24)
                }
            }
            .inputFieldStyle()
        }
    }
}

struct PrimaryButton: View {
    let title: String
    var isDestructive: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(isDestructive ? .white : .black)
                .frame(maxWidth: .infinity)
                .frame(height: 52)
                .background(isDestructive ? AppTheme.danger : Color.white)
                .cornerRadius(AppTheme.cornerRadiusSmall)
        }
    }
}

struct FABButton: View {
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: "plus")
                .font(.system(size: 22, weight: .bold))
                .foregroundColor(.white)
                .frame(width: 58, height: 58)
                .background(
                    Circle()
                        .fill(LinearGradient(
                            colors: [Color(hex: "#00D4AA"), Color(hex: "#009E7E")],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ))
                        .shadow(color: Color(hex: "#00D4AA").opacity(0.5), radius: 14, x: 0, y: 6)
                )
        }
        .buttonStyle(SpringButtonStyle())
    }
}

struct SpringButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.90 : 1.0)
            .animation(.spring(response: 0.25, dampingFraction: 0.55), value: configuration.isPressed)
    }
}

struct ErrorLabel: View {
    let message: String
    var body: some View {
        if !message.isEmpty {
            Text(message)
                .font(.system(size: 13))
                .foregroundColor(AppTheme.danger)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

struct EmptyStateView: View {
    let icon: String
    let title: String
    let subtitle: String

    var body: some View {
        VStack(spacing: 14) {
            Image(systemName: icon)
                .font(.system(size: 52))
                .foregroundColor(AppTheme.textSecondary.opacity(0.4))
            Text(title)
                .font(.system(size: 18, weight: .semibold))
                .foregroundColor(AppTheme.textPrimary)
            Text(subtitle)
                .font(.system(size: 14))
                .foregroundColor(AppTheme.textSecondary)
                .multilineTextAlignment(.center)
        }
        .padding(.horizontal, 40)
    }
}

struct SummaryStatView: View {
    let label: String
    let value: String
    let color: Color

    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(color)
            Text(label)
                .font(.system(size: 11))
                .foregroundColor(AppTheme.textSecondary)
        }
    }
}
