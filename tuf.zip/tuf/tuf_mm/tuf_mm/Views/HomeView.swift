import SwiftUI

struct HomeView: View {

    @Bindable var viewModel: HomeViewModel

    @State private var cardDegrees: Double = 0
    @State private var cardAppeared = false
    @State private var selectedTabIndex = 0
    @State private var tabSlideFromRight = false

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            AppTheme.background.ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    TopBar()
                    greetingSection
                    creditCardSection
                    expensesSection
                    Spacer(minLength: 110)
                }
            }

            FABButton { viewModel.showAddTransaction = true }
                .padding(.trailing, 20)
                .padding(.bottom, 90)
        }
        .onAppear {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.8).delay(0.15)) {
                cardAppeared = true
            }
        }
    }

    // MARK: - Greeting

    private var greetingSection: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("\(viewModel.greeting), \(viewModel.firstName)")
                .font(.system(size: 26, weight: .bold))
                .foregroundColor(AppTheme.textPrimary)
            Text("Track your spending — add a transaction to get started.")
                .font(.system(size: 14))
                .foregroundColor(AppTheme.textSecondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 20)
        .padding(.top, 20)
        .padding(.bottom, 20)
    }

    // MARK: - Credit Card (flip on tap)

    private var creditCardSection: some View {
        ZStack {
            CreditCardFront(user: viewModel.currentUser)
                .opacity(cardDegrees < 90 ? 1 : 0)

            CreditCardBack(
                monthlyIncome:   viewModel.monthlyIncome,
                monthlyExpenses: viewModel.monthlyExpenses
            )
            .scaleEffect(x: -1, y: 1)
            .opacity(cardDegrees >= 90 ? 1 : 0)
        }
        .frame(height: 190)
        .rotation3DEffect(
            .degrees(cardDegrees),
            axis: (x: 0, y: 1, z: 0),
            perspective: 0.4
        )
        .animation(.spring(response: 0.65, dampingFraction: 0.78), value: cardDegrees)
        .onTapGesture {
            cardDegrees = cardDegrees == 0 ? 180 : 0
        }
        .overlay(alignment: .bottomTrailing) {
            Image(systemName: cardDegrees == 0 ? "arrow.counterclockwise.circle" : "arrow.clockwise.circle")
                .font(.system(size: 16))
                .foregroundColor(.white.opacity(0.55))
                .padding(14)
                .allowsHitTesting(false)
        }
        .padding(.horizontal, 20)
        .padding(.bottom, 24)
        .offset(y: cardAppeared ? 0 : 30)
        .opacity(cardAppeared ? 1 : 0)
    }

    // MARK: - Expenses section

    private var expensesSection: some View {
        VStack(spacing: 0) {
            // Header row
            HStack {
                Text("Transactions")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(AppTheme.textPrimary)
                Spacer()
                if viewModel.monthlyExpenses > 0 || viewModel.monthlyIncome > 0 {
                    HStack(spacing: 10) {
                        Label(viewModel.monthlyIncome.formatted(symbol: ""), systemImage: "arrow.up")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(AppTheme.success)
                        Label(viewModel.monthlyExpenses.formatted(symbol: ""), systemImage: "arrow.down")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(AppTheme.danger)
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 14)

            // Segment toggle with bounce
            SegmentControl(
                options: ["Weekly", "Monthly"],
                selectedIndex: $selectedTabIndex
            )
            .padding(.horizontal, 20)
            .padding(.bottom, 18)
            .onChange(of: selectedTabIndex) { oldVal, newVal in
                tabSlideFromRight = newVal > oldVal
                withAnimation(.spring(response: 0.42, dampingFraction: 0.82)) {
                    viewModel.isWeeklyFilter = (newVal == 0)
                }
            }

            transactionList
                .id(viewModel.isWeeklyFilter)
                .transition(
                    .asymmetric(
                        insertion: .move(edge: tabSlideFromRight ? .trailing : .leading)
                            .combined(with: .opacity),
                        removal:   .move(edge: tabSlideFromRight ? .leading : .trailing)
                            .combined(with: .opacity)
                    )
                )
        }
    }

    @ViewBuilder
    private var transactionList: some View {
        if viewModel.groupedTransactions.isEmpty {
            EmptyStateView(
                icon: "chart.bar.doc.horizontal",
                title: "No transactions",
                subtitle: "Tap + to record your first income or expense"
            )
            .padding(.top, 40)
            .transition(.opacity.combined(with: .scale(scale: 0.95)))
        } else {
            LazyVStack(spacing: 0) {
                ForEach(Array(viewModel.groupedTransactions.enumerated()), id: \.element.id) { groupIdx, group in
                    groupSection(group: group, index: groupIdx)
                }
            }
        }
    }

    @ViewBuilder
    private func groupSection(group: HomeViewModel.TransactionGroup, index: Int) -> some View {
        VStack(spacing: 0) {
            HStack {
                Text(group.title)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(AppTheme.textSecondary)
                Spacer()
                HStack(spacing: 8) {
                    if group.totalIncome > 0 {
                        Text("+\(group.totalIncome.formatted(symbol: ""))")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(AppTheme.success)
                    }
                    if group.totalExpense > 0 {
                        Text("-\(group.totalExpense.formatted(symbol: ""))")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(AppTheme.danger)
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 18)
            .padding(.bottom, 10)

            ForEach(Array(group.transactions.enumerated()), id: \.element.id) { txIdx, tx in
                TransactionRow(
                    transaction: tx,
                    currencySymbol: viewModel.currencySymbol(for: tx.currencyId)
                ) {
                    viewModel.toggleFavorite(id: tx.id)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 10)
                .transition(
                    .asymmetric(
                        insertion: .move(edge: tabSlideFromRight ? .trailing : .leading)
                            .combined(with: .opacity),
                        removal: .opacity
                    )
                )
                .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                    Button(role: .destructive) {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.75)) {
                            viewModel.deleteTransaction(id: tx.id)
                        }
                    } label: {
                        Label("Delete", systemImage: "trash")
                    }
                }
            }
        }
        .animation(
            .spring(response: 0.4, dampingFraction: 0.8)
                .delay(Double(index) * 0.06),
            value: viewModel.isWeeklyFilter
        )
    }
}

// MARK: - Credit Card Front

private struct CreditCardFront: View {
    let user: User?

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20)
                .fill(AppTheme.cardGradient)

            Circle().fill(Color.white.opacity(0.05)).frame(width: 130).offset(x: 80,  y: -30)
            Circle().fill(Color.white.opacity(0.04)).frame(width:  90).offset(x: 110, y:  40)

            VStack(alignment: .leading, spacing: 0) {
                HStack {
                    Text(user?.bankName ?? "PayU")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                    Spacer()
                    Image(systemName: "creditcard")
                        .font(.system(size: 22))
                        .foregroundColor(.white.opacity(0.8))
                }
                Spacer()
                Text(user?.cardNumber ?? "•••• •••• •••• ••••")
                    .font(.system(size: 17, weight: .medium, design: .monospaced))
                    .foregroundColor(.white)
                    .tracking(2)
                Spacer()
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Card Holder")
                            .font(.system(size: 10))
                            .foregroundColor(.white.opacity(0.6))
                        Text((user?.fullName ?? "—").uppercased())
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundColor(.white)
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 2) {
                        Text("Expires")
                            .font(.system(size: 10))
                            .foregroundColor(.white.opacity(0.6))
                        Text(user?.cardExpiry ?? "--/--")
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundColor(.white)
                    }
                }
            }
            .padding(20)
        }
    }
}

// MARK: - Credit Card Back

private struct CreditCardBack: View {
    let monthlyIncome: Double
    let monthlyExpenses: Double
    private var net: Double { monthlyIncome - monthlyExpenses }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20)
                .fill(LinearGradient(
                    colors: [Color(hex: "#1A1A2E"), Color(hex: "#16213E"), Color(hex: "#0F3460")],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ))

            Circle().fill(Color.white.opacity(0.04)).frame(width: 150).offset(x: -70, y: 30)

            VStack(spacing: 0) {
                Rectangle()
                    .fill(Color.black.opacity(0.55))
                    .frame(height: 38)
                    .padding(.top, 22)

                Spacer()

                VStack(spacing: 10) {
                    Text("This Month")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor(.white.opacity(0.5))
                        .frame(maxWidth: .infinity, alignment: .leading)

                    HStack(spacing: 0) {
                        backStat(label: "Income",   value: monthlyIncome,   color: Color(hex: "#30D158"))
                        Divider().frame(height: 32).background(Color.white.opacity(0.12))
                        backStat(label: "Expenses", value: monthlyExpenses, color: Color(hex: "#FF453A"))
                        Divider().frame(height: 32).background(Color.white.opacity(0.12))
                        backStat(label: "Net",      value: net,             color: net >= 0 ? Color(hex: "#00D4AA") : Color(hex: "#FF453A"))
                    }

                    Text("Tap card to flip back")
                        .font(.system(size: 9))
                        .foregroundColor(.white.opacity(0.35))
                        .frame(maxWidth: .infinity, alignment: .trailing)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 18)
            }
        }
    }

    private func backStat(label: String, value: Double, color: Color) -> some View {
        VStack(spacing: 3) {
            Text(value.formatted(symbol: ""))
                .font(.system(size: 13, weight: .bold))
                .foregroundColor(color)
                .minimumScaleFactor(0.6)
                .lineLimit(1)
            Text(label)
                .font(.system(size: 9))
                .foregroundColor(.white.opacity(0.45))
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Transaction Row

struct TransactionRow: View {
    let transaction: Transaction
    let currencySymbol: String
    let onFavorite: () -> Void

    @State private var starBounce = false

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(transaction.category.color.opacity(0.18))
                    .frame(width: 46, height: 46)
                Image(systemName: transaction.category.icon)
                    .font(.system(size: 19))
                    .foregroundColor(transaction.category.color)
            }

            VStack(alignment: .leading, spacing: 3) {
                Text(transaction.category.rawValue)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(AppTheme.textPrimary)
                Text(transaction.note.isEmpty
                     ? transaction.date.formatted(date: .abbreviated, time: .omitted)
                     : transaction.note)
                    .font(.system(size: 12))
                    .foregroundColor(AppTheme.textSecondary)
                    .lineLimit(1)
            }

            Spacer()

            Button {
                starBounce = true
                withAnimation(.spring(response: 0.3, dampingFraction: 0.4)) {
                    onFavorite()
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                    starBounce = false
                }
            } label: {
                Image(systemName: transaction.isFavorite ? "star.fill" : "star")
                    .font(.system(size: 17))
                    .foregroundColor(transaction.isFavorite ? AppTheme.warning : AppTheme.textSecondary)
                    .scaleEffect(starBounce ? 1.45 : 1.0)
                    .rotationEffect(.degrees(starBounce ? 15 : 0))
                    .animation(.spring(response: 0.28, dampingFraction: 0.4), value: starBounce)
                    .frame(width: 36, height: 36)
            }
            .buttonStyle(.plain)

            Text(
                "\(transaction.type == .income ? "+" : "-")\(transaction.amount.formatted(symbol: currencySymbol))"
            )
            .font(.system(size: 15, weight: .bold))
            .foregroundStyle(
                transaction.type == .income
                    ? LinearGradient(colors: [Color(hex: "#30D158"), Color(hex: "#34D988")],
                                    startPoint: .topLeading, endPoint: .bottomTrailing)
                    : LinearGradient(colors: [Color(hex: "#FF453A"), Color(hex: "#FF8070")],
                                    startPoint: .topLeading, endPoint: .bottomTrailing)
            )
            .frame(minWidth: 72, alignment: .trailing)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 14)
        .background(AppTheme.cardBg)
        .cornerRadius(AppTheme.cornerRadius)
    }
}
