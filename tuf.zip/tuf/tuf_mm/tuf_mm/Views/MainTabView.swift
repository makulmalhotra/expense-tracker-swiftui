import SwiftUI

struct MainTabView: View {

    @State private var homeVM:     HomeViewModel
    @State private var balancesVM: BalancesViewModel
    @State private var profileVM:  ProfileViewModel

    @State private var selectedTab        = 0
    @State private var showAddTransaction = false

    private let repository: LocalRepository

    init(repository: LocalRepository) {
        self.repository = repository
        _homeVM     = State(initialValue: HomeViewModel(repository: repository))
        _balancesVM = State(initialValue: BalancesViewModel(repository: repository))
        _profileVM  = State(initialValue: ProfileViewModel(repository: repository))
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            tabContent
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .animation(.easeInOut(duration: 0.22), value: selectedTab)

            CustomTabBar(selectedTab: $selectedTab)
        }
        .ignoresSafeArea(edges: .bottom)
        .sheet(isPresented: $showAddTransaction, onDismiss: {
            homeVM.showAddTransaction = false
        }) {
            AddTransactionView(viewModel: AddTransactionViewModel(repository: repository))
                .presentationDragIndicator(.visible)
                .presentationDetents([.large])
        }
        .onChange(of: homeVM.showAddTransaction) { _, show in
            if show { showAddTransaction = true }
        }
    }

    @ViewBuilder
    private var tabContent: some View {
        switch selectedTab {
        case 0:  HomeView(viewModel: homeVM)
        case 1:  BalancesView(viewModel: balancesVM, showAddTransaction: $showAddTransaction)
        default: ProfileView(viewModel: profileVM)
        }
    }
}

private struct CustomTabBar: View {

    @Binding var selectedTab: Int

    private let items: [(icon: String, label: String)] = [
        ("house.fill",      "Home"),
        ("creditcard.fill", "Balances"),
        ("person.fill",     "Profile"),
    ]

    var body: some View {
        HStack(spacing: 0) {
            ForEach(items.indices, id: \.self) { idx in
                Button {
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                        selectedTab = idx
                    }
                } label: {
                    VStack(spacing: 4) {
                        Image(systemName: items[idx].icon)
                            .font(.system(size: 21, weight: selectedTab == idx ? .semibold : .regular))
                            .foregroundColor(selectedTab == idx ? AppTheme.accent : AppTheme.textSecondary)
                            .scaleEffect(selectedTab == idx ? 1.1 : 1)
                            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: selectedTab)
                        Text(items[idx].label)
                            .font(.system(size: 10, weight: .medium))
                            .foregroundColor(selectedTab == idx ? AppTheme.accent : AppTheme.textSecondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                }
            }
        }
        .background(AppTheme.cardBg.ignoresSafeArea(edges: .bottom))
        .overlay(Rectangle().frame(height: 0.5).foregroundColor(AppTheme.separator), alignment: .top)
    }
}
