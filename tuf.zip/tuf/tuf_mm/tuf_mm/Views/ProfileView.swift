import SwiftUI

struct ProfileView: View {

    @Bindable var viewModel: ProfileViewModel
    @State private var showSignOutAlert = false

    var body: some View {
        ZStack {
            AppTheme.background.ignoresSafeArea()

            VStack(spacing: 0) {
                TopBar()
                profileHeader
                modeToggle
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)

                ScrollView(showsIndicators: false) {
                    if viewModel.isEditing {
                        editForm
                            .transition(.asymmetric(
                                insertion: .move(edge: .trailing).combined(with: .opacity),
                                removal:   .move(edge: .leading).combined(with: .opacity)
                            ))
                    } else {
                        previewContent
                            .transition(.asymmetric(
                                insertion: .move(edge: .leading).combined(with: .opacity),
                                removal:   .move(edge: .trailing).combined(with: .opacity)
                            ))
                    }
                }
                .animation(.easeInOut(duration: 0.25), value: viewModel.isEditing)
            }
        }
        .alert("Sign Out", isPresented: $showSignOutAlert) {
            Button("Sign Out", role: .destructive) { viewModel.signOut() }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Are you sure you want to sign out?")
        }
    }

    private var profileHeader: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(AppTheme.surface)
                    .frame(width: 46, height: 46)
                Text(String(viewModel.displayName.prefix(1)).uppercased())
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(AppTheme.textPrimary)
            }

            Text(viewModel.displayName)
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(AppTheme.textPrimary)

            Spacer()

            Button { showSignOutAlert = true } label: {
                Image(systemName: "rectangle.portrait.and.arrow.right")
                    .font(.system(size: 18))
                    .foregroundColor(AppTheme.textSecondary)
            }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 16)
    }

    private var modeToggle: some View {
        let idx = Binding<Int>(
            get: { viewModel.isEditing ? 1 : 0 },
            set: { newVal in
                withAnimation(.easeInOut(duration: 0.2)) {
                    if newVal == 1 { viewModel.startEditing() }
                    else { viewModel.isEditing = false }
                }
            }
        )
        return SegmentControl(options: ["Preview", "Edit"], selectedIndex: idx)
    }

    private var previewContent: some View {
        VStack(spacing: 16) {
            statsCard
            darkModeRow
        }
        .padding(.horizontal, 20)
        .padding(.top, 4)
    }

    private var statsCard: some View {
        VStack(spacing: 0) {
            ProfileInfoRow(label: "Total Spendings", value: viewModel.totalExpenses.formatted())
            Divider().background(AppTheme.separator).padding(.horizontal, 16)
            ProfileInfoRow(label: "Email", value: viewModel.currentUser?.email ?? "—")
            Divider().background(AppTheme.separator).padding(.horizontal, 16)
            ProfileInfoRow(label: "Net Balance", value: viewModel.netBalance.formatted())
            Divider().background(AppTheme.separator).padding(.horizontal, 16)
            ProfileInfoRow(label: "Transactions", value: "\(viewModel.transactionCount)")
        }
        .background(AppTheme.cardBg)
        .cornerRadius(AppTheme.cornerRadius)
    }

    private var darkModeRow: some View {
        HStack {
            Label("Dark Mode", systemImage: "moon.fill")
                .font(.system(size: 15, weight: .medium))
                .foregroundColor(AppTheme.textPrimary)
            Spacer()
            Toggle("", isOn: Binding(
                get: { viewModel.isDarkMode },
                set: { _ in viewModel.toggleDarkMode() }
            ))
            .tint(AppTheme.accent)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 14)
        .background(AppTheme.cardBg)
        .cornerRadius(AppTheme.cornerRadius)
    }

    private var editForm: some View {
        VStack(spacing: 16) {
            InputField(label: "Full Name",
                       placeholder: "Enter your full name",
                       text: $viewModel.editName)

            InputField(label: "Email",
                       placeholder: "Enter your email",
                       text: $viewModel.editEmail,
                       isEmail: true)

            SecureInputField(label: "New Password",
                             placeholder: "Leave blank to keep current",
                             text: $viewModel.editPassword,
                             isVisible: $viewModel.editShowPwd)

            SecureInputField(label: "Confirm Password",
                             placeholder: "Re-enter new password",
                             text: $viewModel.editConfirm,
                             isVisible: $viewModel.editShowConfirm)

            ErrorLabel(message: viewModel.editError)

            PrimaryButton(title: "Update Details") { viewModel.saveChanges() }
                .padding(.top, 8)
        }
        .padding(.horizontal, 20)
        .padding(.bottom, 40)
    }
}

// MARK: - Profile Info Row

private struct ProfileInfoRow: View {
    let label: String
    let value: String

    var body: some View {
        HStack {
            Text(label)
                .font(.system(size: 15))
                .foregroundColor(AppTheme.textSecondary)
            Spacer()
            Text(value)
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(AppTheme.textPrimary)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 14)
    }
}
