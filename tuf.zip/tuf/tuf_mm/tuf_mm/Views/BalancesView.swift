import SwiftUI
import Charts

struct BalancesView: View {

    @Bindable var viewModel: BalancesViewModel
    @Binding var showAddTransaction: Bool

    @State private var showPieChart = false
    @State private var selectedBarMonth: String? = nil
    @State private var chartAppeared = false

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            AppTheme.background.ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    TopBar()
                    headerSection
                    financialHealthCard
                        .padding(.horizontal, 20)
                        .padding(.bottom, 20)
                    summaryRow
                        .padding(.horizontal, 20)
                        .padding(.bottom, 20)
                    currenciesSection
                    chartSection
                    if viewModel.hasCategoryData {
                        categoryPieSection
                    }
                    Spacer(minLength: 110)
                }
            }

            FABButton { showAddTransaction = true }
                .padding(.trailing, 20)
                .padding(.bottom, 90)
        }
        .onAppear {
            withAnimation(.easeOut(duration: 0.6).delay(0.4)) {
                chartAppeared = true
            }
        }
    }

    // MARK: - Header

    private var headerSection: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Your Balances")
                .font(.system(size: 22, weight: .bold))
                .foregroundColor(AppTheme.textPrimary)
            Text("Multi-currency accounts & financial health")
                .font(.system(size: 14))
                .foregroundColor(AppTheme.textSecondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 20)
        .padding(.top, 16)
        .padding(.bottom, 20)
    }

    // MARK: - Financial Health Card (interactive, animated)

    private var financialHealthCard: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20)
                .fill(AppTheme.cardBg)
                .shadow(color: .black.opacity(0.1), radius: 8, x: 0, y: 4)

            VStack(spacing: 12) {
                HStack {
                    Text("Financial Health")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(AppTheme.textPrimary)
                    Spacer()
                    Text(viewModel.financialHealthLabel)
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(scoreColor)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(scoreColor.opacity(0.15))
                        .cornerRadius(8)
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)

                if viewModel.hasTransactions {
                    FinancialHealthGauge(score: viewModel.financialHealthScore)
                        .frame(maxWidth: .infinity)
                        .frame(height: 220)
                        .padding(.horizontal, 20)

                    // Score breakdown hints
                    HStack(spacing: 0) {
                        scoreHint(label: "Income", value: viewModel.currentMonthIncome, color: AppTheme.success)
                        Rectangle().fill(AppTheme.separator).frame(width: 1, height: 32)
                        scoreHint(label: "Expenses", value: viewModel.currentMonthExpenses, color: AppTheme.danger)
                        Rectangle().fill(AppTheme.separator).frame(width: 1, height: 32)
                        scoreHint(label: "Score", value: Double(viewModel.financialHealthScore), color: scoreColor, isInt: true)
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)
                } else {
                    EmptyStateView(
                        icon: "chart.pie",
                        title: "No data yet",
                        subtitle: "Add income & expenses to see your financial health"
                    )
                    .padding(.vertical, 20)
                }
            }
        }
    }

    private var scoreColor: Color {
        switch viewModel.financialHealthScore {
        case ..<450: return AppTheme.danger
        case 450..<600: return AppTheme.warning
        case 600..<730: return Color.yellow
        case 730..<800: return AppTheme.success
        default: return AppTheme.accent
        }
    }

    private func scoreHint(label: String, value: Double, color: Color, isInt: Bool = false) -> some View {
        VStack(spacing: 3) {
            Text(isInt ? "\(Int(value))" : value.formatted())
                .font(.system(size: 13, weight: .bold))
                .foregroundColor(color)
                .minimumScaleFactor(0.7)
                .lineLimit(1)
            Text(label)
                .font(.system(size: 10))
                .foregroundColor(AppTheme.textSecondary)
        }
        .frame(maxWidth: .infinity)
    }

    // MARK: - Monthly Summary Row

    private var summaryRow: some View {
        HStack {
            SummaryStatView(
                label: "Income",
                value: viewModel.currentMonthIncome.formatted(),
                color: AppTheme.success
            )
            Divider().frame(height: 36).background(AppTheme.separator)
            SummaryStatView(
                label: "Expenses",
                value: viewModel.currentMonthExpenses.formatted(),
                color: AppTheme.danger
            )
            Divider().frame(height: 36).background(AppTheme.separator)
            SummaryStatView(
                label: "Balance",
                value: viewModel.netBalance.formatted(),
                color: viewModel.netBalance >= 0 ? AppTheme.success : AppTheme.danger
            )
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 16)
        .padding(.horizontal, 20)
        .background(AppTheme.cardBg)
        .cornerRadius(AppTheme.cornerRadius)
    }

    // MARK: - Currencies

    private var currenciesSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Available Currencies")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(AppTheme.textPrimary)
                .padding(.horizontal, 20)

            ForEach(viewModel.currencies) { currency in
                CurrencyRow(
                    currency: currency,
                    onToggleEnabled:  { viewModel.toggleEnabled(id: currency.id) },
                    onToggleFavorite: { viewModel.toggleFavorite(id: currency.id) }
                )
                .padding(.horizontal, 20)
            }
        }
        .padding(.bottom, 20)
    }

    // MARK: - Bar Chart Section

    private var chartSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Spending Overview")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(AppTheme.textPrimary)
                Spacer()
                // Chart type toggle
                HStack(spacing: 0) {
                    chartTypeButton(label: "Bar", isSelected: !showPieChart) {
                        withAnimation(.easeInOut(duration: 0.25)) { showPieChart = false }
                    }
                    chartTypeButton(label: "Pie", isSelected: showPieChart) {
                        withAnimation(.easeInOut(duration: 0.25)) { showPieChart = true }
                    }
                }
                .background(AppTheme.surface)
                .cornerRadius(8)
            }
            .padding(.horizontal, 20)

            ZStack {
                RoundedRectangle(cornerRadius: 20)
                    .fill(AppTheme.cardBg)
                    .shadow(color: .black.opacity(0.08), radius: 6, x: 0, y: 3)

                if viewModel.hasChartData {
                    VStack(spacing: 0) {
                        if showPieChart {
                            SpendingPieChart(data: viewModel.last6MonthsData)
                                .padding(20)
                                .transition(.opacity.combined(with: .scale(scale: 0.95)))
                        } else {
                            SpendingBarChart(
                                data: viewModel.last6MonthsData,
                                selectedMonth: $selectedBarMonth,
                                appeared: chartAppeared
                            )
                            .padding(16)
                            .transition(.opacity.combined(with: .scale(scale: 0.95)))
                        }

                        // Selected bar detail
                        if let sel = selectedBarMonth,
                           let bar = viewModel.last6MonthsData.first(where: { $0.month == sel }) {
                            HStack(spacing: 20) {
                                Label("\(bar.month) Income: \(bar.income.formatted())", systemImage: "arrow.up.circle.fill")
                                    .font(.system(size: 12, weight: .medium))
                                    .foregroundColor(AppTheme.success)
                                Label("Exp: \(bar.expense.formatted())", systemImage: "arrow.down.circle.fill")
                                    .font(.system(size: 12, weight: .medium))
                                    .foregroundColor(AppTheme.danger)
                            }
                            .padding(.horizontal, 16)
                            .padding(.bottom, 14)
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                        }
                    }
                } else {
                    EmptyStateView(
                        icon: "chart.bar",
                        title: "No chart data",
                        subtitle: "Your spending trends will appear here"
                    )
                    .padding(.vertical, 24)
                }
            }
            .padding(.horizontal, 20)
            .animation(.easeInOut(duration: 0.3), value: selectedBarMonth)
        }
        .padding(.bottom, 20)
    }

    // MARK: - Category Pie Section

    private var categoryPieSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("By Category")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(AppTheme.textPrimary)
                .padding(.horizontal, 20)

            ZStack {
                RoundedRectangle(cornerRadius: 20)
                    .fill(AppTheme.cardBg)
                    .shadow(color: .black.opacity(0.08), radius: 6, x: 0, y: 3)

                VStack(spacing: 16) {
                    CategoryDonutChart(slices: viewModel.spendingByCategory)
                        .frame(height: 200)
                        .padding(.top, 16)

                    categoryLegend
                        .padding(.horizontal, 16)
                        .padding(.bottom, 16)
                }
            }
            .padding(.horizontal, 20)
        }
        .padding(.bottom, 20)
    }

    private var categoryLegend: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
            ForEach(viewModel.spendingByCategory.prefix(6)) { slice in
                HStack(spacing: 6) {
                    Circle()
                        .fill(slice.category.color)
                        .frame(width: 8, height: 8)
                    Text(slice.category.rawValue)
                        .font(.system(size: 11))
                        .foregroundColor(AppTheme.textSecondary)
                        .lineLimit(1)
                    Spacer()
                    Text(String(format: "%.0f%%", slice.percentage))
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(AppTheme.textPrimary)
                }
            }
        }
    }

    private func chartTypeButton(label: String, isSelected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(label)
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(isSelected ? .black : AppTheme.textSecondary)
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(isSelected ? Color.white : Color.clear)
                .cornerRadius(6)
                .padding(2)
        }
    }
}

// MARK: - Financial Health Gauge

struct FinancialHealthGauge: View {

    let score: Int

    @State private var animatedProgress: CGFloat = 0
    @State private var dotPulse = false

    private var scoreProgress: CGFloat {
        CGFloat(max(300, min(850, score)) - 300) / 550.0
    }

    private let sw: CGFloat = 24   // stroke width

    var body: some View {
        GeometryReader { geo in
            let w   = geo.size.width
            let h   = geo.size.height
            let cx  = w / 2
            let cy  = h / 2
            // Keep radius away from edges and leave room for the score text
            let r   = min(cx, cy) - sw / 2 - 6

            // Dot position (driven by animatedProgress — real SwiftUI state, animates correctly)
            let dotDeg = 135.0 + Double(animatedProgress) * 270.0
            let dotRad = dotDeg * .pi / 180.0
            let dotX   = cx + r * CGFloat(cos(dotRad))
            let dotY   = cy + r * CGFloat(sin(dotRad))

            ZStack {
                // ── Arc track + gradient fill (Canvas) ──────────────────────
                Canvas { ctx, size in
                    let center = CGPoint(x: cx, y: cy)
                    let arcPath = Path { p in
                        p.addArc(center: center, radius: r,
                                 startAngle: .degrees(135),
                                 endAngle:   .degrees(405),
                                 clockwise:  false)
                    }

                    // Gray background track
                    ctx.stroke(arcPath,
                               with: .color(.gray.opacity(0.15)),
                               style: StrokeStyle(lineWidth: sw, lineCap: .round))

                    // Gradient: clip filled stroke, paint linear gradient left→right
                    // Works perfectly for a horseshoe arc (starts lower-left, ends lower-right via top)
                    let filled = arcPath.strokedPath(StrokeStyle(lineWidth: sw, lineCap: .round))
                    ctx.drawLayer { c in
                        c.clip(to: filled)
                        c.fill(
                            Path(CGRect(origin: .zero, size: size)),
                            with: .linearGradient(
                                Gradient(colors: [
                                    Color(hex: "#E53935"),   // red   — left / arc start
                                    Color(hex: "#FF8F00"),   // orange
                                    Color(hex: "#FDD835"),   // yellow — top center
                                    Color(hex: "#43A047"),   // green
                                    Color(hex: "#00D4AA"),   // teal  — right / arc end
                                ]),
                                startPoint: CGPoint(x: cx - r - sw, y: cy),
                                endPoint:   CGPoint(x: cx + r + sw, y: cy)
                            )
                        )
                    }
                }

                // ── Pulsing glow ring (SwiftUI, so animation works) ──────────
                Circle()
                    .stroke(Color.white.opacity(0.35), lineWidth: 1.5)
                    .frame(width: 34, height: 34)
                    .scaleEffect(dotPulse ? 2.0 : 1.0)
                    .opacity(dotPulse ? 0 : 0.55)
                    .position(x: dotX, y: dotY)
                    .animation(
                        .easeOut(duration: 1.6).repeatForever(autoreverses: false),
                        value: dotPulse
                    )

                // ── Dot indicator ────────────────────────────────────────────
                Circle()
                    .fill(Color.white)
                    .frame(width: 20, height: 20)
                    .shadow(color: .black.opacity(0.25), radius: 5, x: 0, y: 2)
                    .overlay(
                        Circle()
                            .fill(Color.black.opacity(0.12))
                            .frame(width: 8, height: 8)
                    )
                    .position(x: dotX, y: dotY)

                // ── Score label ──────────────────────────────────────────────
                VStack(spacing: 2) {
                    Text("\(score)")
                        .font(.system(size: 48, weight: .bold))
                        .foregroundColor(AppTheme.textPrimary)
                        .contentTransition(.numericText())
                        .animation(.spring(response: 0.9, dampingFraction: 0.7), value: score)
                    Text("out of 850")
                        .font(.system(size: 11))
                        .foregroundColor(AppTheme.textSecondary)
                }
                .position(x: cx, y: cy + 12)
            }
        }
        .onAppear {
            withAnimation(.spring(response: 1.4, dampingFraction: 0.65).delay(0.3)) {
                animatedProgress = scoreProgress
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) {
                dotPulse = true
            }
        }
        .onChange(of: score) { _, _ in
            withAnimation(.spring(response: 0.9, dampingFraction: 0.7)) {
                animatedProgress = scoreProgress
            }
        }
    }
}

// MARK: - Currency Row

private struct CurrencyRow: View {
    let currency: Currency
    let onToggleEnabled:  () -> Void
    let onToggleFavorite: () -> Void

    var body: some View {
        HStack(spacing: 12) {
            Text(currency.flag)
                .font(.system(size: 26))
                .frame(width: 46, height: 46)
                .background(AppTheme.surface)
                .cornerRadius(12)

            VStack(alignment: .leading, spacing: 2) {
                Text(currency.id)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(AppTheme.textPrimary)
                Text(currency.name)
                    .font(.system(size: 12))
                    .foregroundColor(AppTheme.textSecondary)
            }

            Spacer()

            Button(action: onToggleFavorite) {
                Image(systemName: currency.isFavorite ? "star.fill" : "star")
                    .font(.system(size: 15))
                    .foregroundColor(currency.isFavorite ? AppTheme.warning : AppTheme.textSecondary)
            }

            Button(action: onToggleEnabled) {
                Text(currency.isEnabled ? "Enabled" : "+ Enable")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(currency.isEnabled ? AppTheme.accent : AppTheme.textPrimary)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(currency.isEnabled
                                ? AppTheme.accent.opacity(0.15)
                                : AppTheme.surface)
                    .cornerRadius(8)
            }
            .animation(.easeInOut(duration: 0.2), value: currency.isEnabled)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(AppTheme.cardBg)
        .cornerRadius(AppTheme.cornerRadius)
    }
}

// MARK: - Spending Bar Chart (interactive, animated)

private struct SpendingBarChart: View {
    let data: [BalancesViewModel.MonthlyBar]
    @Binding var selectedMonth: String?
    let appeared: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 16) {
                legendDot(color: AppTheme.success, label: "Income")
                legendDot(color: AppTheme.danger,  label: "Expense")
                Spacer()
                Text("Last 6 months")
                    .font(.system(size: 11))
                    .foregroundColor(AppTheme.textSecondary)
            }

            Chart {
                ForEach(data) { bar in
                    BarMark(
                        x: .value("Month", bar.month),
                        y: .value("Income", appeared ? bar.income : 0)
                    )
                    .foregroundStyle(
                        selectedMonth == nil || selectedMonth == bar.month
                            ? AppTheme.success.opacity(0.85)
                            : AppTheme.success.opacity(0.25)
                    )
                    .cornerRadius(5)

                    BarMark(
                        x: .value("Month", bar.month),
                        y: .value("Expense", appeared ? bar.expense : 0)
                    )
                    .foregroundStyle(
                        selectedMonth == nil || selectedMonth == bar.month
                            ? AppTheme.danger.opacity(0.85)
                            : AppTheme.danger.opacity(0.25)
                    )
                    .cornerRadius(5)
                }
            }
            .chartXAxis {
                AxisMarks { _ in
                    AxisValueLabel()
                        .foregroundStyle(AppTheme.textSecondary)
                }
            }
            .chartYAxis {
                AxisMarks { _ in
                    AxisGridLine().foregroundStyle(AppTheme.separator)
                    AxisValueLabel().foregroundStyle(AppTheme.textSecondary)
                }
            }
            .chartOverlay { proxy in
                GeometryReader { geo in
                    Rectangle().fill(.clear).contentShape(Rectangle())
                        .gesture(
                            DragGesture(minimumDistance: 0)
                                .onChanged { value in
                                    let origin = geo[proxy.plotFrame!].origin
                                    let location = CGPoint(
                                        x: value.location.x - origin.x,
                                        y: value.location.y - origin.y
                                    )
                                    if let month: String = proxy.value(atX: location.x) {
                                        withAnimation(.easeInOut(duration: 0.15)) {
                                            selectedMonth = month
                                        }
                                    }
                                }
                                .onEnded { _ in
                                    withAnimation(.easeInOut(duration: 0.3).delay(1.5)) {
                                        selectedMonth = nil
                                    }
                                }
                        )
                }
            }
            .frame(height: 160)
            .animation(.spring(response: 0.7, dampingFraction: 0.75), value: appeared)
        }
    }

    private func legendDot(color: Color, label: String) -> some View {
        HStack(spacing: 4) {
            Circle().fill(color).frame(width: 8, height: 8)
            Text(label)
                .font(.system(size: 11))
                .foregroundColor(AppTheme.textSecondary)
        }
    }
}

// MARK: - Spending Pie Chart (income vs expense summary)

private struct SpendingPieChart: View {
    let data: [BalancesViewModel.MonthlyBar]

    private var totalIncome: Double  { data.reduce(0) { $0 + $1.income } }
    private var totalExpense: Double { data.reduce(0) { $0 + $1.expense } }

    struct PieSlice: Identifiable {
        let id = UUID()
        let label: String
        let value: Double
        let color: Color
    }

    private var slices: [PieSlice] {
        [
            PieSlice(label: "Income",   value: totalIncome,  color: AppTheme.success),
            PieSlice(label: "Expenses", value: totalExpense, color: AppTheme.danger)
        ].filter { $0.value > 0 }
    }

    var body: some View {
        if slices.isEmpty {
            EmptyStateView(icon: "chart.pie", title: "No data", subtitle: "Add transactions to see breakdown")
        } else {
            VStack(spacing: 12) {
                Chart(slices) { slice in
                    SectorMark(
                        angle: .value(slice.label, slice.value),
                        innerRadius: .ratio(0.5),
                        angularInset: 3
                    )
                    .foregroundStyle(slice.color)
                    .cornerRadius(6)
                }
                .frame(height: 180)

                HStack(spacing: 24) {
                    ForEach(slices) { slice in
                        HStack(spacing: 6) {
                            Circle().fill(slice.color).frame(width: 10, height: 10)
                            VStack(alignment: .leading, spacing: 1) {
                                Text(slice.label)
                                    .font(.system(size: 12))
                                    .foregroundColor(AppTheme.textSecondary)
                                Text(slice.value.formatted())
                                    .font(.system(size: 13, weight: .bold))
                                    .foregroundColor(AppTheme.textPrimary)
                            }
                        }
                    }
                }
            }
        }
    }
}

// MARK: - Category Donut Chart

private struct CategoryDonutChart: View {
    let slices: [BalancesViewModel.CategorySlice]
    @State private var appeared = false

    var body: some View {
        Chart(slices) { slice in
            SectorMark(
                angle: .value("Amount", appeared ? slice.amount : 0),
                innerRadius: .ratio(0.52),
                angularInset: 2
            )
            .foregroundStyle(slice.category.color)
            .cornerRadius(5)
            .annotation(position: .overlay) {
                if slice.percentage >= 8 {
                    Text(String(format: "%.0f%%", slice.percentage))
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundColor(.white)
                }
            }
        }
        .animation(.spring(response: 1.0, dampingFraction: 0.7), value: appeared)
        .onAppear {
            withAnimation(.spring(response: 1.0, dampingFraction: 0.7).delay(0.1)) {
                appeared = true
            }
        }
    }
}
