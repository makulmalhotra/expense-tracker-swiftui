import SwiftUI

struct AddTransactionView: View {

    @Bindable var viewModel: AddTransactionViewModel
    @Environment(\.dismiss) private var dismiss

    @FocusState private var amountFocused: Bool
    @State private var appeared = false

    var body: some View {
        ZStack {
            AppTheme.background.ignoresSafeArea()

            VStack(spacing: 0) {
                titleRow
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                    .padding(.bottom, 16)
                    .offset(y: appeared ? 0 : -10)
                    .opacity(appeared ? 1 : 0)

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 18) {
                        typeToggle
                            .staggerAppear(appeared: appeared, delay: 0.05)

                        amountField
                            .staggerAppear(appeared: appeared, delay: 0.10)

                        currencyPicker
                            .staggerAppear(appeared: appeared, delay: 0.15)

                        categoryPicker
                            .staggerAppear(appeared: appeared, delay: 0.20)

                        dateField
                            .staggerAppear(appeared: appeared, delay: 0.25)

                        noteField
                            .staggerAppear(appeared: appeared, delay: 0.30)

                        ErrorLabel(message: viewModel.errorMessage)
                            .staggerAppear(appeared: appeared, delay: 0.32)

                        submitButton
                            .staggerAppear(appeared: appeared, delay: 0.35)
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 40)
                }
            }
        }
        .onAppear {
            amountFocused = true
            withAnimation(.spring(response: 0.55, dampingFraction: 0.82)) {
                appeared = true
            }
        }
    }

    // MARK: - Title Row

    private var titleRow: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text("Add Transaction")
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(AppTheme.textPrimary)
            Text(viewModel.transactionType == .expense ? "Record an expense" : "Record an income")
                .font(.system(size: 12))
                .foregroundColor(AppTheme.textSecondary)
                .animation(.easeInOut(duration: 0.2), value: viewModel.transactionType)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    // MARK: - Type Toggle (gradient)

    private var typeToggle: some View {
        HStack(spacing: 0) {
            typeButton(.expense, label: "Expense",
                       gradient: LinearGradient(colors: [Color(hex: "#FF453A"), Color(hex: "#FF6B6B")],
                                               startPoint: .topLeading, endPoint: .bottomTrailing))
            typeButton(.income, label: "Income",
                       gradient: LinearGradient(colors: [Color(hex: "#30D158"), Color(hex: "#34D988")],
                                               startPoint: .topLeading, endPoint: .bottomTrailing))
        }
        .background(AppTheme.surface)
        .cornerRadius(10)
    }

    private func typeButton(_ type: TransactionType, label: String, gradient: LinearGradient) -> some View {
        Button {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                viewModel.transactionType = type
            }
        } label: {
            HStack(spacing: 6) {
                Image(systemName: type == .expense ? "arrow.down.circle.fill" : "arrow.up.circle.fill")
                    .font(.system(size: 14))
                Text(label)
                    .font(.system(size: 15, weight: .semibold))
            }
            .foregroundColor(viewModel.transactionType == type ? .white : AppTheme.textSecondary)
            .frame(maxWidth: .infinity)
            .frame(height: 44)
            .background(
                Group {
                    if viewModel.transactionType == type {
                        gradient
                    } else {
                        LinearGradient(colors: [Color.clear], startPoint: .top, endPoint: .bottom)
                    }
                }
            )
            .cornerRadius(8)
            .padding(3)
            .scaleEffect(viewModel.transactionType == type ? 1.0 : 0.96)
            .animation(.spring(response: 0.3, dampingFraction: 0.7), value: viewModel.transactionType)
        }
    }

    // MARK: - Amount Field

    private var amountField: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Amount")
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(AppTheme.textSecondary)

            HStack {
                Text(viewModel.selectedCurrencySymbol)
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(AppTheme.accent)
                    .contentTransition(.identity)

                TextField("0.00", text: $viewModel.amountText)
                    .keyboardType(.decimalPad)
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(AppTheme.textPrimary)
                    .focused($amountFocused)
                    .onChange(of: viewModel.amountText) { _, newValue in
                        var filtered = newValue.filter { $0.isNumber || $0 == "." }
                        var dotCount = 0
                        filtered = String(filtered.filter { ch in
                            if ch == "." {
                                dotCount += 1
                                return dotCount <= 1
                            }
                            return true
                        })
                        if filtered != newValue {
                            viewModel.amountText = filtered
                        }
                    }

                if !viewModel.amountText.isEmpty {
                    Button {
                        withAnimation(.easeInOut(duration: 0.15)) {
                            viewModel.amountText = ""
                        }
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 16))
                            .foregroundColor(AppTheme.textSecondary.opacity(0.6))
                    }
                    .transition(.scale.combined(with: .opacity))
                }
            }
            .inputFieldStyle(focused: amountFocused)
            .overlay(
                RoundedRectangle(cornerRadius: AppTheme.cornerRadiusSmall)
                    .strokeBorder(
                        amountFocused
                            ? (viewModel.transactionType == .expense
                               ? Color(hex: "#FF453A").opacity(0.5)
                               : Color(hex: "#30D158").opacity(0.5))
                            : Color.clear,
                        lineWidth: 1.5
                    )
                    .animation(.easeInOut(duration: 0.2), value: amountFocused)
            )
        }
    }

    // MARK: - Currency Picker

    private var currencyPicker: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Currency")
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(AppTheme.textSecondary)

            if viewModel.enabledCurrencies.isEmpty {
                Text("No currencies enabled. Enable currencies in the Balances tab.")
                    .font(.system(size: 13))
                    .foregroundColor(AppTheme.textSecondary)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 12)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(AppTheme.inputBg)
                    .cornerRadius(AppTheme.cornerRadiusSmall)
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        ForEach(viewModel.enabledCurrencies) { currency in
                            Button {
                                withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                    viewModel.selectedCurrencyId = currency.id
                                }
                            } label: {
                                HStack(spacing: 6) {
                                    Text(currency.flag)
                                        .font(.system(size: 18))
                                    VStack(alignment: .leading, spacing: 1) {
                                        Text(currency.id)
                                            .font(.system(size: 13, weight: .semibold))
                                            .foregroundColor(
                                                viewModel.selectedCurrencyId == currency.id
                                                    ? .white : AppTheme.textPrimary
                                            )
                                        Text(currency.symbol)
                                            .font(.system(size: 11))
                                            .foregroundColor(
                                                viewModel.selectedCurrencyId == currency.id
                                                    ? .white.opacity(0.75) : AppTheme.textSecondary
                                            )
                                    }
                                }
                                .padding(.horizontal, 14)
                                .padding(.vertical, 10)
                                .background(
                                    viewModel.selectedCurrencyId == currency.id
                                        ? AppTheme.accent : AppTheme.cardBg
                                )
                                .cornerRadius(10)
                                .scaleEffect(viewModel.selectedCurrencyId == currency.id ? 1.04 : 1.0)
                                .animation(.spring(response: 0.3, dampingFraction: 0.7), value: viewModel.selectedCurrencyId)
                            }
                        }
                    }
                    .padding(.vertical, 2)
                }
            }
        }
    }

    // MARK: - Category Picker

    private var categoryPicker: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Category")
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(AppTheme.textSecondary)

            LazyVGrid(columns: [GridItem(.adaptive(minimum: 78))], spacing: 10) {
                ForEach(TransactionCategory.allCases) { cat in
                    CategoryChip(
                        category: cat,
                        isSelected: viewModel.selectedCategory == cat
                    ) {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.65)) {
                            viewModel.selectedCategory = cat
                        }
                    }
                }
            }
        }
    }

    // MARK: - Date Field

    private var dateField: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Date")
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(AppTheme.textSecondary)

            DatePicker("", selection: $viewModel.date, displayedComponents: .date)
                .datePickerStyle(.compact)
                .labelsHidden()
                .tint(AppTheme.accent)
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .background(AppTheme.inputBg)
                .cornerRadius(AppTheme.cornerRadiusSmall)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    // MARK: - Note Field

    private var noteField: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Note (optional)")
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(AppTheme.textSecondary)

            TextField("e.g. Grocery run, Salary deposit…", text: $viewModel.note)
                .font(.system(size: 15))
                .foregroundColor(AppTheme.textPrimary)
                .inputFieldStyle()
        }
    }

    // MARK: - Submit Button

    private var submitButton: some View {
        Button {
            if viewModel.submit() { dismiss() }
        } label: {
            HStack(spacing: 8) {
                Image(systemName: viewModel.transactionType == .expense
                      ? "arrow.down.circle.fill" : "arrow.up.circle.fill")
                    .font(.system(size: 18))
                Text("Save Transaction")
                    .font(.system(size: 16, weight: .semibold))
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 54)
            .background(
                Group {
                    if viewModel.isAmountValid {
                        if viewModel.transactionType == .expense {
                            LinearGradient(colors: [Color(hex: "#FF453A"), Color(hex: "#FF6B6B")],
                                          startPoint: .leading, endPoint: .trailing)
                        } else {
                            LinearGradient(colors: [Color(hex: "#30D158"), Color(hex: "#34D988")],
                                          startPoint: .leading, endPoint: .trailing)
                        }
                    } else {
                        LinearGradient(colors: [AppTheme.surface, AppTheme.surface],
                                      startPoint: .leading, endPoint: .trailing)
                    }
                }
            )
            .cornerRadius(AppTheme.cornerRadiusSmall)
            .animation(.easeInOut(duration: 0.2), value: viewModel.transactionType)
            .animation(.easeInOut(duration: 0.15), value: viewModel.isAmountValid)
        }
        .disabled(!viewModel.isAmountValid)
        .buttonStyle(SpringButtonStyle())
        .padding(.top, 4)
    }
}

// MARK: - Stagger Appear Modifier

private struct StaggerAppear: ViewModifier {
    let appeared: Bool
    let delay: Double

    func body(content: Content) -> some View {
        content
            .offset(y: appeared ? 0 : 16)
            .opacity(appeared ? 1 : 0)
            .animation(
                .spring(response: 0.5, dampingFraction: 0.8).delay(delay),
                value: appeared
            )
    }
}

private extension View {
    func staggerAppear(appeared: Bool, delay: Double) -> some View {
        modifier(StaggerAppear(appeared: appeared, delay: delay))
    }
}

// MARK: - Category Chip

struct CategoryChip: View {
    let category: TransactionCategory
    let isSelected: Bool
    let action: () -> Void

    @State private var bounced = false

    var body: some View {
        Button {
            bounced = true
            action()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { bounced = false }
        } label: {
            VStack(spacing: 5) {
                Image(systemName: category.icon)
                    .font(.system(size: 18))
                    .foregroundColor(isSelected ? .white : category.color)
                    .scaleEffect(bounced ? 1.3 : 1.0)
                    .animation(.spring(response: 0.25, dampingFraction: 0.45), value: bounced)
                Text(category.rawValue)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(isSelected ? .white : AppTheme.textSecondary)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .background(
                isSelected
                    ? LinearGradient(colors: [category.color, category.color.opacity(0.75)],
                                    startPoint: .topLeading, endPoint: .bottomTrailing)
                    : LinearGradient(colors: [AppTheme.cardBg, AppTheme.cardBg],
                                    startPoint: .topLeading, endPoint: .bottomTrailing)
            )
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .strokeBorder(isSelected ? category.color.opacity(0.3) : Color.clear, lineWidth: 1)
            )
            .scaleEffect(isSelected ? 1.04 : 1.0)
        }
    }
}
