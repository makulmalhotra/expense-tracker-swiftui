import SwiftUI

struct AuthView: View {

    @Bindable var viewModel: AuthViewModel

    @State private var logoScale:   CGFloat = 0.4
    @State private var logoOpacity: Double  = 0

    var body: some View {
        ZStack {
            AppTheme.background.ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    header
                    getStartedLabel
                    tabToggle
                    formArea
                }
                .padding(.bottom, 40)
            }
        }
        .onAppear {
            withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
                logoScale   = 1
                logoOpacity = 1
            }
        }
    }

    private var header: some View {
        VStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 16)
                    .fill(Color.white)
                    .frame(width: 68, height: 68)
                    .shadow(color: .white.opacity(0.1), radius: 12)
                Text("P")
                    .font(.system(size: 34, weight: .bold))
                    .foregroundColor(.black)
            }
            .scaleEffect(logoScale)
            .opacity(logoOpacity)
            .padding(.top, 60)

            Text("Welcome to PayU")
                .font(.system(size: 26, weight: .bold))
                .foregroundColor(AppTheme.textPrimary)

            Text("Send money globally with the real exchange rate")
                .font(.system(size: 14))
                .foregroundColor(AppTheme.textSecondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 48)
        }
        .padding(.bottom, 32)
    }

    private var getStartedLabel: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Get started")
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(AppTheme.textPrimary)
            Text("Sign in to your account or create a new one")
                .font(.system(size: 14))
                .foregroundColor(AppTheme.textSecondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 24)
        .padding(.bottom, 20)
    }

    private var tabToggle: some View {
        let binding = Binding<Int>(
            get: { viewModel.activeTab == .signIn ? 0 : 1 },
            set: { viewModel.activeTab = $0 == 0 ? .signIn : .signUp }
        )
        return SegmentControl(options: ["Sign In", "Sign Up"], selectedIndex: binding)
            .padding(.horizontal, 24)
            .padding(.bottom, 24)
    }

    @ViewBuilder
    private var formArea: some View {
        switch viewModel.activeTab {
        case .signIn:
            signInForm
                .transition(.asymmetric(
                    insertion: .move(edge: .leading).combined(with: .opacity),
                    removal:   .move(edge: .trailing).combined(with: .opacity)
                ))
        case .signUp:
            signUpForm
                .transition(.asymmetric(
                    insertion: .move(edge: .trailing).combined(with: .opacity),
                    removal:   .move(edge: .leading).combined(with: .opacity)
                ))
        }
    }

    private var signInForm: some View {
        VStack(spacing: 16) {
            InputField(label: "Email",
                       placeholder: "Enter your email",
                       text: $viewModel.signInEmail,
                       isEmail: true)

            SecureInputField(label: "Password",
                             placeholder: "Enter your password",
                             text: $viewModel.signInPassword,
                             isVisible: $viewModel.signInShowPwd)

            HStack {
                Spacer()
                Button("Forgot password?") {}
                    .font(.system(size: 13))
                    .foregroundColor(AppTheme.accent)
            }

            ErrorLabel(message: viewModel.signInError)

            PrimaryButton(title: "Sign In") { viewModel.signIn() }
                .padding(.top, 8)
        }
        .padding(.horizontal, 24)
    }

    private var signUpForm: some View {
        VStack(spacing: 16) {
            InputField(label: "Full Name",
                       placeholder: "Enter your full name",
                       text: $viewModel.signUpName)

            InputField(label: "Email",
                       placeholder: "Enter your email",
                       text: $viewModel.signUpEmail,
                       isEmail: true)

            SecureInputField(label: "Password",
                             placeholder: "Create a password (min 8 characters)",
                             text: $viewModel.signUpPassword,
                             isVisible: $viewModel.signUpShowPwd)

            SecureInputField(label: "Confirm Password",
                             placeholder: "Re-enter your password",
                             text: $viewModel.signUpConfirm,
                             isVisible: $viewModel.signUpShowConfirm)

            ErrorLabel(message: viewModel.signUpError)

            PrimaryButton(title: "Create Account") { viewModel.signUp() }
                .padding(.top, 8)
        }
        .padding(.horizontal, 24)
    }
}
