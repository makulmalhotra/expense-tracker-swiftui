import Foundation
import SwiftUI

struct User: Identifiable, Codable, Equatable {
    let id: UUID
    var fullName: String
    var email: String
    var password: String
    var cardNumber: String
    var bankName: String
    var cardExpiry: String
}

struct Transaction: Identifiable, Codable, Equatable {
    let id: UUID
    var type: TransactionType
    var amount: Double
    var category: TransactionCategory
    var date: Date
    var note: String
    var isFavorite: Bool
    var currencyId: String

    init(
        id: UUID = UUID(),
        type: TransactionType,
        amount: Double,
        category: TransactionCategory,
        date: Date = Date(),
        note: String = "",
        isFavorite: Bool = false,
        currencyId: String = "CAD"
    ) {
        self.id = id
        self.type = type
        self.amount = amount
        self.category = category
        self.date = date
        self.note = note
        self.isFavorite = isFavorite
        self.currencyId = currencyId
    }

    // Older saves won't have currencyId — default to CAD
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        id         = try c.decode(UUID.self,                forKey: .id)
        type       = try c.decode(TransactionType.self,     forKey: .type)
        amount     = try c.decode(Double.self,              forKey: .amount)
        category   = try c.decode(TransactionCategory.self, forKey: .category)
        date       = try c.decode(Date.self,                forKey: .date)
        note       = try c.decode(String.self,              forKey: .note)
        isFavorite = try c.decode(Bool.self,                forKey: .isFavorite)
        currencyId = try c.decodeIfPresent(String.self,     forKey: .currencyId) ?? "CAD"
    }
}

enum TransactionType: String, Codable, CaseIterable, Identifiable {
    case income  = "Income"
    case expense = "Expense"
    var id: String { rawValue }
}

enum TransactionCategory: String, Codable, CaseIterable, Identifiable {
    case food          = "Food"
    case travel        = "Travel"
    case shopping      = "Shopping"
    case entertainment = "Entertainment"
    case health        = "Health"
    case salary        = "Salary"
    case transport     = "Transport"
    case utilities     = "Utilities"
    case investment    = "Investment"
    case other         = "Other"

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .food:          return "fork.knife"
        case .travel:        return "airplane"
        case .shopping:      return "bag.fill"
        case .entertainment: return "tv.fill"
        case .health:        return "heart.fill"
        case .salary:        return "banknote.fill"
        case .transport:     return "car.fill"
        case .utilities:     return "bolt.fill"
        case .investment:    return "chart.line.uptrend.xyaxis"
        case .other:         return "ellipsis.circle.fill"
        }
    }

    var color: Color {
        switch self {
        case .food:          return .orange
        case .travel:        return .blue
        case .shopping:      return .purple
        case .entertainment: return .pink
        case .health:        return .red
        case .salary:        return Color(hex: "#30D158")
        case .transport:     return .cyan
        case .utilities:     return .yellow
        case .investment:    return Color(hex: "#00D4AA")
        case .other:         return .gray
        }
    }
}

struct Currency: Identifiable, Codable, Equatable {
    let id: String
    let name: String
    let flag: String
    let symbol: String
    var isEnabled: Bool
    var isFavorite: Bool

    static let defaults: [Currency] = [
        Currency(id: "CAD", name: "Canadian Dollar",   flag: "🇨🇦", symbol: "CA$", isEnabled: true,  isFavorite: false),
        Currency(id: "USD", name: "US Dollar",         flag: "🇺🇸", symbol: "$",   isEnabled: false, isFavorite: false),
        Currency(id: "EUR", name: "Euro",              flag: "🇪🇺", symbol: "€",   isEnabled: false, isFavorite: false),
        Currency(id: "GBP", name: "British Pound",     flag: "🇬🇧", symbol: "£",   isEnabled: false, isFavorite: false),
        Currency(id: "AUD", name: "Australian Dollar", flag: "🇦🇺", symbol: "A$",  isEnabled: false, isFavorite: false),
    ]
}
