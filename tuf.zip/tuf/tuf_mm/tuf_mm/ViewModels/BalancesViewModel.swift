import Foundation
import SwiftUI
import Observation

@Observable
final class BalancesViewModel {

    private unowned let repository: LocalRepository

    init(repository: LocalRepository) {
        self.repository = repository
    }

    // Score range: 300 (poor) – 850 (excellent)
    var financialHealthScore: Int {
        guard currentMonthIncome > 0 else { return 300 }
        let rate = max(0, min(1, (currentMonthIncome - currentMonthExpenses) / currentMonthIncome))
        return 300 + Int(rate * 550)
    }

    var financialHealthLabel: String {
        switch financialHealthScore {
        case ..<450:    return "Needs Attention"
        case 450..<550: return "Fair"
        case 550..<650: return "Average"
        case 650..<730: return "Good"
        case 730..<800: return "Very Good"
        default:        return "Excellent"
        }
    }

    var hasTransactions: Bool { !repository.transactions.isEmpty }

    var currentMonthIncome: Double {
        currentMonthTransactions.filter { $0.type == .income }.reduce(0) { $0 + $1.amount }
    }

    var currentMonthExpenses: Double {
        currentMonthTransactions.filter { $0.type == .expense }.reduce(0) { $0 + $1.amount }
    }

    var netBalance: Double { currentMonthIncome - currentMonthExpenses }

    struct MonthlyBar: Identifiable {
        let id       = UUID()
        let month: String
        let sortDate: Date
        let income: Double
        let expense: Double
    }

    var last6MonthsData: [MonthlyBar] {
        let cal = Calendar.current
        let fmt = DateFormatter()
        fmt.dateFormat = "MMM"
        return (0..<6).reversed().compactMap { offset -> MonthlyBar? in
            guard let anchor = cal.date(byAdding: .month, value: -offset, to: Date()) else { return nil }
            let txs = repository.transactions.filter {
                cal.isDate($0.date, equalTo: anchor, toGranularity: .month)
            }
            return MonthlyBar(
                month:    fmt.string(from: anchor),
                sortDate: anchor,
                income:   txs.filter { $0.type == .income  }.reduce(0) { $0 + $1.amount },
                expense:  txs.filter { $0.type == .expense }.reduce(0) { $0 + $1.amount }
            )
        }
    }

    var hasChartData: Bool { last6MonthsData.contains { $0.income > 0 || $0.expense > 0 } }

    struct CategorySlice: Identifiable {
        let id       = UUID()
        let category: TransactionCategory
        let amount: Double
        let percentage: Double
    }

    var spendingByCategory: [CategorySlice] {
        let expenses = repository.transactions.filter { $0.type == .expense }
        let total    = expenses.reduce(0) { $0 + $1.amount }
        guard total > 0 else { return [] }
        var dict: [TransactionCategory: Double] = [:]
        for tx in expenses { dict[tx.category, default: 0] += tx.amount }
        return dict.compactMap { cat, amount -> CategorySlice? in
            guard amount > 0 else { return nil }
            return CategorySlice(category: cat, amount: amount, percentage: amount / total * 100)
        }.sorted { $0.amount > $1.amount }
    }

    var hasCategoryData: Bool { !spendingByCategory.isEmpty }

    var currencies: [Currency] { repository.currencies }

    func toggleEnabled(id: String)  { repository.toggleCurrencyEnabled(id: id) }
    func toggleFavorite(id: String) { repository.toggleCurrencyFavorite(id: id) }

    private var currentMonthTransactions: [Transaction] {
        repository.transactions.filter {
            Calendar.current.isDate($0.date, equalTo: Date(), toGranularity: .month)
        }
    }
}
