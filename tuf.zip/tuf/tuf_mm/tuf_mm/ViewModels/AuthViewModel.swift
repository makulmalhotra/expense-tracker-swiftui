import Foundation
import Observation

@Observable
final class AuthViewModel {

    enum Tab { case signIn, signUp }
    var activeTab: Tab = .signIn

    var signInEmail    = ""
    var signInPassword = ""
    var signInShowPwd  = false
    var signInError    = ""

    var signUpName        = ""
    var signUpEmail       = ""
    var signUpPassword    = ""
    var signUpConfirm     = ""
    var signUpShowPwd     = false
    var signUpShowConfirm = false
    var signUpError       = ""

    private unowned let repository: LocalRepository

    init(repository: LocalRepository) {
        self.repository = repository
    }

    func signIn() {
        signInError = ""
        guard validate(signInEmail, signInPassword, context: .signIn) else { return }
        if let error = repository.signIn(email: signInEmail, password: signInPassword) {
            signInError = error
        }
    }

    func signUp() {
        signUpError = ""
        guard validate(signUpEmail, signUpPassword, context: .signUp) else { return }
        if let error = repository.signUp(fullName: signUpName, email: signUpEmail, password: signUpPassword) {
            signUpError = error
        }
    }

    private enum ValidationContext { case signIn, signUp }

    private func validate(_ email: String, _ password: String, context: ValidationContext) -> Bool {
        if context == .signUp {
            guard !signUpName.trimmingCharacters(in: .whitespaces).isEmpty else {
                signUpError = "Full name is required."; return false
            }
        }
        guard !email.trimmingCharacters(in: .whitespaces).isEmpty else {
            set(error: "Email is required.", context: context); return false
        }
        guard isValidEmail(email) else {
            set(error: "Enter a valid email address.", context: context); return false
        }
        guard !password.isEmpty else {
            set(error: "Password is required.", context: context); return false
        }
        if context == .signUp {
            guard password.count >= 8 else {
                signUpError = "Password must be at least 8 characters."; return false
            }
            guard password == signUpConfirm else {
                signUpError = "Passwords do not match."; return false
            }
        }
        return true
    }

    private func set(error: String, context: ValidationContext) {
        switch context {
        case .signIn: signInError = error
        case .signUp: signUpError = error
        }
    }

    private func isValidEmail(_ email: String) -> Bool {
        let regex = #"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$"#
        return email.range(of: regex, options: .regularExpression) != nil
    }
}
