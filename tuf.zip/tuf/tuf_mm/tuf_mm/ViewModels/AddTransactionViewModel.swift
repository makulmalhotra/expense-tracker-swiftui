import Foundation
import Observation

@Observable
final class AddTransactionViewModel {

    var transactionType: TransactionType      = .expense
    var amountText: String                    = ""
    var selectedCategory: TransactionCategory = .food
    var selectedCurrencyId: String            = "CAD"
    var date: Date                            = Date()
    var note: String                          = ""
    var errorMessage: String                  = ""

    private unowned let repository: LocalRepository

    init(repository: LocalRepository) {
        self.repository = repository
        selectedCurrencyId = repository.currencies.first(where: \.isEnabled)?.id ?? "CAD"
    }

    var parsedAmount: Double? {
        Double(amountText.trimmingCharacters(in: .whitespaces))
    }

    var isAmountValid: Bool {
        guard let v = parsedAmount else { return false }
        return v > 0 && v < 1_000_000_000
    }

    var enabledCurrencies: [Currency] {
        repository.currencies.filter(\.isEnabled)
    }

    var selectedCurrencySymbol: String {
        repository.currencies.first(where: { $0.id == selectedCurrencyId })?.symbol ?? "$"
    }

    func submit() -> Bool {
        errorMessage = ""
        guard !amountText.trimmingCharacters(in: .whitespaces).isEmpty else {
            errorMessage = "Amount is required."; return false
        }
        guard let amount = parsedAmount, amount > 0 else {
            errorMessage = "Enter a valid amount greater than zero."; return false
        }
        guard amount < 1_000_000_000 else {
            errorMessage = "Amount exceeds the maximum allowed value."; return false
        }
        let tx = Transaction(
            type:       transactionType,
            amount:     amount,
            category:   selectedCategory,
            date:       date,
            note:       note.trimmingCharacters(in: .whitespacesAndNewlines),
            currencyId: selectedCurrencyId
        )
        repository.addTransaction(tx)
        return true
    }

    func reset() {
        transactionType    = .expense
        amountText         = ""
        selectedCategory   = .food
        selectedCurrencyId = repository.currencies.first(where: \.isEnabled)?.id ?? "CAD"
        date               = Date()
        note               = ""
        errorMessage       = ""
    }
}
