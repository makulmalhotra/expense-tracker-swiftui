import Foundation
import Observation

@Observable
final class ProfileViewModel {

    var isEditing        = false
    var editName         = ""
    var editEmail        = ""
    var editPassword     = ""
    var editConfirm      = ""
    var editShowPwd      = false
    var editShowConfirm  = false
    var editError        = ""
    var didUpdateSuccess = false

    private unowned let repository: LocalRepository

    init(repository: LocalRepository) {
        self.repository = repository
    }

    var isDarkMode: Bool      { repository.isDarkMode }
    var currentUser: User?    { repository.currentUser }
    var displayName: String   { repository.currentUser?.fullName ?? "User" }
    var transactionCount: Int { repository.transactions.count }

    var totalExpenses: Double {
        repository.transactions.filter { $0.type == .expense }.reduce(0) { $0 + $1.amount }
    }

    var totalIncome: Double {
        repository.transactions.filter { $0.type == .income }.reduce(0) { $0 + $1.amount }
    }

    var netBalance: Double { totalIncome - totalExpenses }

    func startEditing() {
        guard let user = repository.currentUser else { return }
        editName         = user.fullName
        editEmail        = user.email
        editPassword     = ""
        editConfirm      = ""
        editError        = ""
        didUpdateSuccess = false
        isEditing        = true
    }

    func saveChanges() {
        editError = ""
        didUpdateSuccess = false

        guard !editName.trimmingCharacters(in: .whitespaces).isEmpty else {
            editError = "Full name is required."; return
        }
        guard !editEmail.trimmingCharacters(in: .whitespaces).isEmpty else {
            editError = "Email is required."; return
        }
        let newPwd: String? = editPassword.isEmpty ? nil : editPassword
        if let pwd = newPwd {
            guard pwd.count >= 8 else { editError = "Password must be at least 8 characters."; return }
            guard pwd == editConfirm else { editError = "Passwords do not match."; return }
        }
        if let error = repository.updateProfile(fullName: editName, email: editEmail, newPassword: newPwd) {
            editError = error
        } else {
            didUpdateSuccess = true
            isEditing = false
        }
    }

    func toggleDarkMode() { repository.setDarkMode(!repository.isDarkMode) }
    func signOut()         { repository.signOut() }
}
